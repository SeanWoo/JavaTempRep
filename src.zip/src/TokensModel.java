public class TokensModel {
    public String accessToken;
    //+ refresh_token
    public TokensModel(String token){
        accessToken = token;
    }
}
